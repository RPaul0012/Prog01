//Royce Paul
//893720896
//Section 02
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.Arrays;

/**
 * <Prog01_aOrderedList is where the main program is kept. Each of the methods used to create and populate the input and output files are in this class.>
 *
 * CSC 1351 Programming Project No <Prog01_aOrderedList>
 7
 * Section <2>
 *
 * @author <Royce Paul>
 * @since <October 23, 2023>
 *
 */
class Prog01_aOrderedList {
    static aOrderedList aOrderedListObject;
    public static void main(String[] args) throws FileNotFoundException {
        File inputFile = new File("input1.txt");
        File outputFile = new File("output1.txt");
        aOrderedListObject = new aOrderedList();
        Scanner sc = getFileName("Y");
        readInputFile(sc);
        PrintWriter pw = getOutputFileName("Y");
        printOutputFile(pw);


    }
    /**
     * <getFileName takes in the userinput to find the input file for the program. The method begins by acting as if the user input Y and then asks for the file name. If the file doesn't exist, the program asks whether the user would like to repeat the loop.
     * Once the file is found, the sc scanner receives it an the next method begins.
     *
     * CSC 1351 Programming Project No <Prog01_aOrderedList>
     * Section <2>
     *
     * @author <Royce Paul>
     * @since <October 23, 2023>
     *
     */
    public static Scanner getFileName(String userPrompt) throws FileNotFoundException
    {
        Scanner scan = new Scanner(System.in);
        File inputFile;
        String fileName;
        String response;
        if (userPrompt.equals("Y")) {
            System.out.println("Enter input fileName:");
            fileName = scan.next();
            inputFile = new File(fileName);
            if (!inputFile.exists()) {
                System.out.println("File specified" + " <" + fileName + "> " + "does not exist. Would you like to continue ? <Y/N>");
                response = scan.next();
                getFileName(response);


            } else {
                scan = new Scanner(new File(fileName));
                return scan;
            }
        } else
            throw new FileNotFoundException();
        return null;
    }
    /**
     * <The getOutputFileName method is used to let the user input the name of the output file.>
     *
     *
     * CSC 1351 Programming Project No <Prog01_aOrderedList>
     * Section <2>
     *
     * @author <Royce Paul>
     * @since <October 23, 2023>
     *
     */
    public static PrintWriter getOutputFileName(String userPrompt) throws FileNotFoundException
    {
        Scanner scan = new Scanner(System.in);
        File outputFile;
        String fileName;
        String response;
        PrintWriter pw;
        if (userPrompt.equals("Y")) {
            System.out.println("Enter input fileName:");
            fileName = scan.next();
            outputFile = new File(fileName);
            if (!outputFile.exists()) {
                System.out.println("File specified " + " <" + fileName + "> " + " does not exist. Would you like to continue? <Y/N>");
                response = scan.next();
                getOutputFileName(response);
            }
            else
            {
                pw = new PrintWriter(new File(fileName));
                return pw;
            }
        }
        else
            throw new FileNotFoundException();
        return null;
    }
    /**
     * <Method to read input file and add car object to list.>
     *
     *
     * CSC 1351 Programming Project No <Prog01_aOrderedList>
     * Section <2>
     *
     * @author <Royce Paul>
     * @since <October 23, 2023>
     *
     */
    public static void readInputFile(Scanner sc) throws FileNotFoundException
    {
        sc = sc.useDelimiter("\\,");
        String operation, make;
        int year, price, index;
        operation = sc.next();
        do {
            if (operation.equals('A'))
            {
                make = sc.next();
                year = sc.nextInt();
                price = sc.nextInt();
                Car newCar = new Car(make, year, price);
                aOrderedListObject.addCar(newCar);
                sc.nextLine();


            }
            if (operation.equals("D"))
            {
                index = sc.nextInt();
                aOrderedListObject.removeCar(index);
            }
        }
        while (sc.hasNextLine());
    }
    /**
     * <Method to print output file.>
     *
     *
     * CSC 1351 Programming Project No <Prog01_aOrderedList>
     * Section <2>
     *
     * @author <Royce Paul>
     * @since <October 23, 2023>
     *
     */
    public static void printOutputFile(PrintWriter pw)
    {
        pw.print("Number of cars : " + aOrderedListObject.getSize());
        pw.println();
        for (int i = 0; i < aOrderedListObject.getSize(); i++) {
            pw.println("Make :" + aOrderedListObject.getCar(i).getMake());
            pw.println("Year :" + aOrderedListObject.getCar(i).getYear());
            pw.println("Price :" + aOrderedListObject.getCar(i).getPrice());
            pw.println();
        }


    }
}
/**
 * <aOrderedList is where the methods used for the array list within the text files are held.>
 *
 * CSC 1351 Programming Project No <Prog01_aOrderedList>
 7
 * Section <2>
 *
 * @author <Royce Paul>
 * @since <October 23, 2023>
 *
 */
class aOrderedList
{
    final int sizeIncrements = 20;
    private Car[] oList;
    private int listSize;
    private int numObjects;
    /** <aOrderedList is responsible for sorting the cars list>
     *
     * CSC 1351 Programming Project No <Prog01_aOrderedList>
     * Section <2>
     * @author <Royce Paul>
     * @since <October 23, 2023>
     *
     */
    public aOrderedList()
    {
        numObjects = 0;
        listSize = sizeIncrements;
        oList = new Car[sizeIncrements];
    }
    /** <Method to add car object>
     *
     * CSC 1351 Programming Project No <Prog01_aOrderedList>
     * Section <2>
     * @author <Royce Paul>
     * @since <October 23, 2023>
     *
     */
    public void addCar(Car car)
    {
        oList[numObjects] = car;
        numObjects++;
        if (numObjects >= oList.length) {
            Car[] tempList = Arrays.copyOf(oList, 2 * oList.length);
            oList = tempList;
        }
        sortList();
    }

    public String toString()
    {
        if (oList.length > 0)
        {
            for (int i = 0; i < oList.length; i++)
            {
                return "[" + oList[i].toString() + "]";
            }
        }
        return "[]";
    }
    /** <Method to sort array going from car to car>
     *
     * CSC 1351 Programming Project No <Prog01_aOrderedList>
     * Section <2>
     * @author <Royce Paul>
     * @since <October 23, 2023>
     *
     */
    public void sortList()
    {
        for (int i = 0; i < oList.length - 1; i++) {
            for (int j = i + 1; j < oList.length; j++) {
                if (oList[i].compareTo(oList[j]) > 1) {
                    Car temp_car = oList[i];
                    oList[i] = oList[j];
                    oList[j] = temp_car;
                }
            }
        }


    }
    /** <Method to get array size>
     *
     * CSC 1351 Programming Project No <Prog01_aOrderedList>
     * Section <2>
     * @author <Royce Paul>
     * @since <October 23, 2023>
     *
     */
    public int getSize()
    {
        return numObjects;
    }
    /** <Method to get Car Object at specified index>
     *
     * CSC 1351 Programming Project No <Prog01_aOrderedList>
     * Section <2>
     * @author <Royce Paul>
     * @since <October 23, 2023>
     *
     */
    public Car getCar(int index)
    {
        return oList[index];
    }
    /** <Method to check if array is empty>
     *
     * CSC 1351 Programming Project No <Prog01_aOrderedList>
     * Section <2>
     * @author <Royce Paul>
     * @since <October 23, 2023>
     *
     */
    public boolean isEmpty()
    {
        if (numObjects == 0) return true;
        return false;
    }
    /** <Method to remove Car Object>
     *
     * CSC 1351 Programming Project No <Prog01_aOrderedList>
     * Section <2>
     * @author <Royce Paul>
     * @since <October 23, 2023>
     *
     */
    public void removeCar(int index)
    {
        if (index <= numObjects) {
            for (int i = index; i < numObjects; i++) {
                oList[i] = oList[i + 1];
            }
            oList[numObjects] = null;
            numObjects--;
        }
    }


}

/** < Class Car is where the "Car" object and the Car array list is defined in terms of size and organization>
 *
 * CSC 1351 Programming Project No <Prog01_aOrderedList>
 * Section <2>
 * @author <Royce Paul>
 * @since <October 23, 2023>
 *
 */
class Car implements Comparable<Car>
{


    private String make;
    private int year;
    private int price;



    public Car(String make, int year, int price) {
        this.make = make;
        this.year = year;
        this.price = price;
    }
    /** <Method to get make of the car>
     *
     * CSC 1351 Programming Project No <Prog01_aOrderedList>
     * Section <2>
     * @author <Royce Paul>
     * @since <October 23, 2023>
     *
     */
    public String getMake() {
        return make;
    }
    /** <Method to get year of the car>
     *
     * CSC 1351 Programming Project No <Prog01_aOrderedList>
     * Section <2>
     * @author <Royce Paul>
     * @since <October 23, 2023>
     *
     */
    public int getYear() {
        return year;
    }
    /** <Method to get price of the ca>
     *
     * CSC 1351 Programming Project No <Prog01_aOrderedList>
     * Section <2>
     * @author <Royce Paul>
     * @since <October 23, 2023>
     *
     */

    public int getPrice() {
        return price;
    }
    /** <Method to compare cars based on the year and price>
     *
     * CSC 1351 Programming Project No <Prog01_aOrderedList>
     * Section <2>
     * @author <Royce Paul>
     * @since <October 23, 2023>
     *
     */
    public int compareTo(Car anotherCar) {
        if (this.year > anotherCar.year) return 1;
        if (this.year < anotherCar.year) return -1;
        if (this.year == anotherCar.year) {
            if (this.price > anotherCar.price) return 1;
            if (this.price < anotherCar.price) return -1;
        }
        return 0;
    }

    public String toString()
    {
        return "Make :" + make + ", Year :" + year + ", Price" + price + ";";
    }
}
